// --- Variáveis Globais ---
let dinheiro = 500;
let alimentos = 100;
let ovos = 0; // Exemplo de produto animal

let campo = []; // Representa os talhões de terra
let numTalhoesX = 10;
let numTalhoesY = 8;
let tamanhoTalhao;

// Tipos de Plantação (para referência)
const TIPO_VAZIO = 0;
const TIPO_MILHO = 1;
const TIPO_TRIGO = 2;
const TIPO_CENOURA = 3;

// Status da Plantação
const STATUS_PLANTADO = 0;
const STATUS_CRESCENDO = 1;
const STATUS_PRONTO_COLHEITA = 2;

// Custos e Valores
const CUSTO_PLANTAR_MILHO = 10;
const VALOR_VENDA_MILHO = 15;
const TEMPO_CRESCIMENTO_MILHO = 300; // Em frames

let modoAcao = 'selecionar'; // 'selecionar', 'plantar_milho', 'colher'

// --- Setup: Configuração Inicial do Jogo ---
function setup() {
  createCanvas(800, 600); // Cria uma tela de 800x600 pixels
  textAlign(CENTER, CENTER);
  textSize(16);

  tamanhoTalhao = width / numTalhoesX; // Calcula o tamanho de cada talhão

  // Inicializa o campo com talhões vazios
  for (let i = 0; i < numTalhoesY; i++) {
    campo[i] = [];
    for (let j = 0; j < numTalhoesX; j++) {
      campo[i][j] = {
        tipo: TIPO_VAZIO,
        status: null,
        tempoCrescimento: 0,
        x: j * tamanhoTalhao,
        y: i * tamanhoTalhao
      };
    }
  }

  // Criar botões de ação (por enquanto, apenas um para plantar milho)
  // Posicionaremos os botões abaixo da área do campo, ajustando a altura do canvas se necessário.
  let yBotoes = numTalhoesY * tamanhoTalhao + 20; // Posição Y para os botões

  let btnPlantarMilho = createButton('Plantar Milho ($' + CUSTO_PLANTAR_MILHO + ')');
  btnPlantarMilho.position(20, yBotoes);
  btnPlantarMilho.mousePressed(() => modoAcao = 'plantar_milho');

  let btnColher = createButton('Colher');
  btnColher.position(btnPlantarMilho.x + btnPlantarMilho.width + 10, yBotoes);
  btnColher.mousePressed(() => modoAcao = 'colher');

  // Ajusta a altura do canvas para caber os botões
  resizeCanvas(width, yBotoes + 60);
}

// --- Draw: Loop Principal do Jogo ---
function draw() {
  background(135, 206, 235); // Céu azul

  // Desenhar o campo
  desenharCampo();

  // Atualizar o estado das plantações
  atualizarPlantacoes();

  // Desenhar a interface do usuário (dinheiro, recursos)
  desenharInterface();
}

// --- Funções de Lógica do Jogo ---

function atualizarPlantacoes() {
  for (let i = 0; i < numTalhoesY; i++) {
    for (let j = 0; j < numTalhoesX; j++) {
      let talhao = campo[i][j];

      if (talhao.tipo !== TIPO_VAZIO && talhao.status === STATUS_CRESCENDO) {
        talhao.tempoCrescimento++;
        // Verifica se a plantação está pronta para colheita
        if (talhao.tipo === TIPO_MILHO && talhao.tempoCrescimento >= TEMPO_CRESCIMENTO_MILHO) {
          talhao.status = STATUS_PRONTO_COLHEITA;
        }
        // Adicionar lógica para outros tipos de plantação aqui
      }
    }
  }
}

// --- Funções de Desenho ---

function desenharCampo() {
  for (let i = 0; i < numTalhoesY; i++) {
    for (let j = 0; j < numTalhoesX; j++) {
      let talhao = campo[i][j];
      let x = talhao.x;
      let y = talhao.y;

      stroke(100, 50, 0); // Borda marrom
      strokeWeight(1);

      // Desenha o talhão (terra)
      fill(160, 82, 45); // Cor de terra
      rect(x, y, tamanhoTalhao, tamanhoTalhao);

      // Desenha a plantação se houver
      if (talhao.tipo === TIPO_MILHO) {
        if (talhao.status === STATUS_PLANTADO || talhao.status === STATUS_CRESCENDO) {
          // Desenha pequenas sementes ou brotos
          fill(50, 100, 0); // Verde escuro
          ellipse(x + tamanhoTalhao / 2, y + tamanhoTalhao / 2, 10, 10);
          // Representação do crescimento (simplificada)
          if (talhao.tempoCrescimento > TEMPO_CRESCIMENTO_MILHO / 2) {
            rect(x + tamanhoTalhao / 2 - 2, y + tamanhoTalhao / 2 - 15, 4, 30);
          }
        } else if (talhao.status === STATUS_PRONTO_COLHEITA) {
          // Desenha o milho maduro
          fill(255, 255, 0); // Amarelo para o milho
          rect(x + tamanhoTalhao / 2 - 5, y + tamanhoTalhao / 2 - 20, 10, 40);
          fill(255, 165, 0); // Laranja para os grãos
          ellipse(x + tamanhoTalhao / 2, y + tamanhoTalhao / 2 + 10, 8, 15);
        }
      }
      // Adicionar desenho para outros tipos de plantação e animais aqui
    }
  }
}

function desenharInterface() {
  fill(0); // Cor do texto
  text(`Dinheiro: $${dinheiro}`, 100, height - 30);
  text(`Alimentos: ${alimentos}`, 250, height - 30);
  text(`Ovos: ${ovos}`, 400, height - 30);
  text(`Modo: ${modoAcao.toUpperCase()}`, width - 100, height - 30);
}

// --- Funções de Interação (Cliques do Mouse) ---

function mousePressed() {
  // Converte as coordenadas do mouse para o índice do talhão no grid
  let col = floor(mouseX / tamanhoTalhao);
  let row = floor(mouseY / tamanhoTalhao);

  // Verifica se o clique está dentro da área do campo
  if (col >= 0 && col < numTalhoesX && row >= 0 && row < numTalhoesY) {
    let talhaoClicado = campo[row][col];

    if (modoAcao === 'plantar_milho') {
      if (talhaoClicado.tipo === TIPO_VAZIO && dinheiro >= CUSTO_PLANTAR_MILHO) {
        dinheiro -= CUSTO_PLANTAR_MILHO;
        talhaoClicado.tipo = TIPO_MILHO;
        talhaoClicado.status = STATUS_CRESCENDO;
        talhaoClicado.tempoCrescimento = 0;
        console.log("Milho plantado!");
      } else if (dinheiro < CUSTO_PLANTAR_MILHO) {
        console.log("Dinheiro insuficiente para plantar milho.");
      } else {
        console.log("Este talhão já está ocupado.");
      }
    } else if (modoAcao === 'colher') {
      if (talhaoClicado.tipo === TIPO_MILHO && talhaoClicado.status === STATUS_PRONTO_COLHEITA) {
        alimentos += 5; // Exemplo: cada milho colhido rende 5 alimentos
        dinheiro += VALOR_VENDA_MILHO; // Vende automaticamente ao colher (simplificado)
        talhaoClicado.tipo = TIPO_VAZIO; // Talhão volta a ficar vazio
        talhaoClicado.status = null;
        talhaoClicado.tempoCrescimento = 0;
        console.log("Milho colhido e vendido!");
      } else if (talhaoClicado.tipo === TIPO_VAZIO) {
        console.log("Não há nada para colher aqui.");
      } else {
        console.log("Esta plantação ainda não está pronta para colher.");
      }
    }
  }
}